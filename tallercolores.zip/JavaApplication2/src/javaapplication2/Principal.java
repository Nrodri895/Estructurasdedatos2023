package javaapplication2;

public class Principal {
    public static void main(String[] args) {
        reloj r1 = new reloj("rojo", "rojos", "blancas", "Jaime");
        r1.sonar();
        r1.girar();
    }
}