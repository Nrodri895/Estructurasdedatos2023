package javaapplication2;

public class reloj {
    private String bordeColor;
    private String piesColor;
    private String manezillasColor;
    private String nombre;

    public reloj(String bordeColor, String piesColor, String manezillasColor, String nombre) {
        this.bordeColor = bordeColor;
        this.piesColor = piesColor;
        this.manezillasColor = manezillasColor;
        this.nombre = nombre;
    }
    
    public String getBordeColor() {
        return bordeColor;
    }

    public void setBordeColor(String bordeColor) {
        this.bordeColor = bordeColor;
    }

    public String getPiesColor() {
        return piesColor;
    }

    public void setPiesColor(String piesColor) {
        this.piesColor = piesColor;
    }

    public String getManezillasColor() {
        return manezillasColor;
    }

    public void setManezillasColor(String manezillasColor) {
        this.manezillasColor = manezillasColor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void girar() {
        System.out.println(nombre + " Esta girando");
    }
    
    public void sonar() {
        System.out.println("La alarma de " +nombre+" a empezado a sonar");
    }
}
